<?php die(); // Test file for testing remote transfers. You may delete this file if found on your destination server.
