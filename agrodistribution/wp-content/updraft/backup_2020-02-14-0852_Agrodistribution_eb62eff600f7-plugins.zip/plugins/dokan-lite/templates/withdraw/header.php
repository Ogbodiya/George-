<?php
/**
 * Dokan Dashboard Withdra Header Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>
<header class="dokan-dashboard-header">
    <h1 class="entry-title"><?php esc_html_e( 'Withdraw', 'dokan-lite' ); ?></h1>
</header><!-- .entry-header -->
